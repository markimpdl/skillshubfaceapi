﻿using FaceApi.Models;

namespace FaceApi.Services
{
    public interface IUserService
    {
        public Task<User> CreateUserAsync(string name, string basePhotoUrl, List<int> schoolIds);
        public Task<List<User>> GetAllAsync();
        public Task<User> GetByIdAsync(int id);
    }
}
