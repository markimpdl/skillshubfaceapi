﻿using FaceApi.DTOs;
using FaceApi.Models;
using FaceApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FaceApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IAzureBlobService _azureBlobService;
        private readonly IAzureFaceService _azureFaceService;

        public UsersController(IUserService userService, 
            IAzureBlobService azureBlobService,
            IAzureFaceService azureFaceService)
        {
            _userService = userService;
            _azureBlobService = azureBlobService;
            _azureFaceService = azureFaceService;
        } 

        [HttpPost]
        public async Task<IActionResult> Create([FromForm] CreateUserDto dto)
        {
            if (dto.Photo == null || dto.Photo.Length == 0)
                return BadRequest("É necessário enviar uma foto.");

            // Gera nome único
            string uniqueFileName = $"{Guid.NewGuid()}{Path.GetExtension(dto.Photo.FileName)}";

            // Faz upload para o Azure Blob e obtém a URL
            string photoUrl = await _azureBlobService.UploadAsync(dto.Photo, uniqueFileName);


            // Chama seu serviço de cadastro, salvando a URL no campo certo
            var user = await _userService.CreateUserAsync(dto.Name, photoUrl, dto.SchoolIds);

            foreach (var schoolId in dto.SchoolIds)
            {
                string groupId = $"escola_{schoolId}";
                await _azureFaceService.CreatePersonGroupAsync(groupId, groupId); // idempotente
                string personId = await _azureFaceService.CreatePersonAsync(groupId, dto.Name);
                await _azureFaceService.AddFaceToPersonAsync(groupId, personId, photoUrl);
                await _azureFaceService.TrainPersonGroupAsync(groupId);

                // Relacione o User à escola, e salve o personId daquele grupo
                user.UserSchools.Add(new UserSchool { UserId = user.Id, SchoolId = schoolId, AzurePersonId = personId ,  });
            }



            return Ok(user);
        }


        [HttpGet]
        public async Task<IActionResult> GetAll()
            => Ok(await _userService.GetAllAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
            => Ok(await _userService.GetByIdAsync(id));
    }
}
