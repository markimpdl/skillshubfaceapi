﻿using Microsoft.AspNetCore.Identity;

namespace FaceApi.Models
{
    public class AdministratorUser : IdentityUser
    {
    }
}
