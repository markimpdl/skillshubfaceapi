﻿namespace FaceApi.DTOs
{
    public class PresenceCheckinDto
    {
        public int SchoolId { get; set; }
        public IFormFile Photo { get; set; }
    }
}
