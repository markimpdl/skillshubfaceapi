﻿namespace FaceApi.DTOs
{
    public class CreateSchoolDto
    {
        public string Name { get; set; }
    }
}
